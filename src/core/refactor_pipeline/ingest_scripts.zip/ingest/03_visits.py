"""Visits file: one row per ED visit with complaint, vitals and diagnosis.

In:  swed_ed_core, every lab/meas file in VITAL_SOURCES, sos_patreg_wide
Out: OUT_DIR/visits.parquet, one row per visit, 15 columns:
     lopnr_swed           int64
     ed_hospital          category
     ed_arrival_datetime  timestamp, UTC
     complaint            category  SNOMED code of the first complaint in ed_presented_complaint_std
                                    (null if none)
     <concept>            first reading in the visit window, for each concept in CONCEPTS:
                            float64  blodtryck_sys, blodtryck_dia, puls, temperatur,
                                     indirekt_oximetri, andning, news2, news
                            string   avpu, metvetenhet (the text as recorded)
     diagnosis            string    Hdia of the first patreg contact within 30 days, or
                                    "NODIAG" = patreg covers the 30 days but has no contact, or
                                    null     = the 30 days run past the end of patreg (2016-12-31)

Which term names count as which concept: VITAL_TERMS in ingest_common.py.

Rules (from v2/phase1 where it settled them):
  - Visits with ed_inexact_time = TRUE are dropped: their clock time is unknown, so
    the vitals window can't be placed (the documentation says to remove them).
  - Vitals window: arrival - 60 min until arrival + ed_time_total_minutes
    (24 h when that is missing). First reading per concept, by time. A reading goes
    to the patient's latest visit whose window has opened.
  - Readings with inexact_time = TRUE or no value are dropped. Numeric readings come
    from value_num (or a number in value_str when value_num is empty) and are dropped
    outside PLAUSIBLE; SpO2 written as a fraction (0-1) is scaled to percent.
  - "Blodtryck" readings like "120/80" (in value_str) become one blodtryck_sys and one
    blodtryck_dia reading with the same time; ones that can't be split are counted and dropped.
  - Diagnosis: Hdia only, INDATUM in [arrival local date, + 30 days], both ends
    included. Ties on the same INDATUM keep the row read first.

Memory: holds the ~7.4M visits plus reduced vitals in memory (several GB on the full data;
run with sbatch -n 8). Every file is read in batches of at most BATCH_SIZE rows.

    python 03_visits.py
"""
import pandas as pd
import ingest_common as C

ED_COLUMNS = ["lopnr_swed", "ed_hospital", "ed_arrival_datetime", "ed_inexact_time",
              "ed_age", "ed_presented_complaint_std", "ed_time_total_minutes"]
VITAL_COLUMNS = ["lopnr_swed", "datetime_analysis", "term_name"]  # required
VITAL_OPTIONAL = ["value_num", "value_str", "inexact_time"]  # read when the file has them
PATREG_COLUMNS = ["lopnr_swed", "INDATUM", "Hdia"]
COMPACT_EVERY = 20  # batches between merges of the partial vitals/diagnosis results
BP_PATTERN = r"^\s*(\d{2,3})\s*/\s*(\d{2,3})\s*$"


# ------------------------------------------------------------------- visits ---
def load_visits():
    path = C.source_path(C.ED_CORE)
    C.log(f"reading visits from {path}")
    parts = []
    offset = n_inexact = n_excluded = 0
    for b in C.iter_batches(path, ED_COLUMNS):
        b["visit_id"] = range(offset, offset + len(b))
        offset += len(b)
        b["lopnr_swed"] = C.to_lopnr(b["lopnr_swed"])
        inexact = b["ed_inexact_time"].fillna(False).astype(bool)
        excluded = ~C.not_excluded(b)
        n_inexact += int(inexact.sum())
        n_excluded += int((excluded & ~inexact).sum())
        b = b.loc[~inexact & ~excluded].copy()
        b["complaint"] = b["ed_presented_complaint_std"].str.extract(r"\[(\d+)\]", expand=False)
        parts.append(b.drop(columns=["ed_presented_complaint_std", "ed_inexact_time"]))

    v = pd.concat(parts, ignore_index=True)
    for col in ["ed_hospital", "complaint"]:
        v[col] = v[col].astype("category")
    v["visit_id"] = v["visit_id"].astype("int64")
    v["ed_arrival_datetime"] = C.as_utc(v["ed_arrival_datetime"])
    n_dup = int(v.duplicated(["lopnr_swed", "ed_arrival_datetime"]).sum())
    C.log(f"visits read {offset:,} | inexact time dropped {n_inexact:,} | excluded {n_excluded:,} | "
          f"kept {len(v):,} | same patient+arrival duplicates {n_dup:,}")
    C.log(f"visits without a complaint code: {int(v['complaint'].isna().sum()):,}")
    return v


# ------------------------------------------------------------------- vitals ---
def visit_windows(v):
    arrival = v["ed_arrival_datetime"].dt.tz_convert(None)  # naive UTC, for merge_asof
    total = v["ed_time_total_minutes"]
    C.log(f"visits without ed_time_total_minutes (window = {C.VITALS_FALLBACK_MIN} min): "
          f"{int(total.isna().sum()):,}")
    total = total.fillna(C.VITALS_FALLBACK_MIN)
    w = pd.DataFrame({
        "visit_id": v["visit_id"].values,
        "lopnr_swed": v["lopnr_swed"].values,
        "arrival": arrival.values,
        "win_start": (arrival - pd.Timedelta(minutes=C.VITALS_BEFORE_MIN)).values,
        "win_end": (arrival + pd.to_timedelta(total, unit="m")).values,
    })
    return w.sort_values("win_start", kind="mergesort").reset_index(drop=True)


def new_vital_stats():
    return {"read": 0, "vital_rows": 0, "inexact": 0, "bp_unsplit": 0,
            "no_value": 0, "implausible": 0, "matched": 0}


def text_of(b):
    """Recorded text per row: value_str, else value_num written without a trailing .0."""
    text = pd.Series(pd.NA, index=b.index, dtype="object")
    if "value_str" in b.columns:
        text = b["value_str"].astype("object").str.strip()
        text = text.where(text != "", pd.NA)
    if "value_num" in b.columns:
        num = pd.to_numeric(b["value_num"], errors="coerce")
        as_text = num.map(lambda x: pd.NA if pd.isna(x) else ("%g" % x))
        text = text.where(text.notna(), as_text)
    return text


def number_of(b):
    """Numeric value per row: value_num, else a number in value_str (comma decimals allowed)."""
    num = pd.Series(float("nan"), index=b.index)
    if "value_num" in b.columns:
        num = pd.to_numeric(b["value_num"], errors="coerce")
    if "value_str" in b.columns:
        from_str = pd.to_numeric(b["value_str"].astype("object").str.strip().str.replace(",", ".", regex=False),
                                 errors="coerce")
        num = num.where(num.notna(), from_str)
    return num.astype("float64")


def clean_vital_batch(b, stats, unmatched):
    """Rows of the wanted vitals with a usable time and value.
    Returns lopnr_swed, t, concept, value (float, numeric concepts) and text (text concepts)."""
    concept = b["term_name"].map(C.VITAL_TERMS)

    other = b.loc[concept.isna(), "term_name"].value_counts()
    if len(other):
        like = pd.Series(other.index, dtype="object").str.contains(C.VITAL_LIKE_PATTERN, case=False, na=False)
        for term, n in other[like.values].items():
            unmatched[term] = unmatched.get(term, 0) + int(n)

    b = b.loc[concept.notna()].copy()
    b["concept"] = concept[concept.notna()].astype("object")
    stats["vital_rows"] += len(b)
    if "inexact_time" in b.columns:
        inexact = b["inexact_time"].fillna(False).astype(bool)
        stats["inexact"] += int(inexact.sum())
        b = b.loc[~inexact]
    b = b.loc[b["datetime_analysis"].notna()]
    b["value"] = number_of(b)
    b["text"] = text_of(b)

    # split combined blood pressure "120/80" into a systolic and a diastolic reading
    is_bp = b["concept"] == C.BP_COMBINED
    if is_bp.any():
        bp = b.loc[is_bp]
        parts = bp["text"].astype("object").str.extract(BP_PATTERN)
        ok = parts[0].notna()
        stats["bp_unsplit"] += int((~ok).sum())
        sys_rows = bp.loc[ok].assign(concept="blodtryck_sys", value=pd.to_numeric(parts.loc[ok, 0]))
        dia_rows = bp.loc[ok].assign(concept="blodtryck_dia", value=pd.to_numeric(parts.loc[ok, 1]))
        b = pd.concat([b.loc[~is_bp], sys_rows, dia_rows], ignore_index=True)

    numeric = b["concept"].isin(C.NUMERIC_CONCEPTS)
    b.loc[numeric, "text"] = pd.NA
    b.loc[~numeric, "value"] = float("nan")
    no_value = (numeric & b["value"].isna()) | (~numeric & b["text"].isna())
    stats["no_value"] += int(no_value.sum())
    b = b.loc[~no_value]

    numeric = b["concept"].isin(C.NUMERIC_CONCEPTS)
    fraction = (b["concept"] == "indirekt_oximetri") & (b["value"] > 0) & (b["value"] <= 1)
    b.loc[fraction, "value"] = b.loc[fraction, "value"] * 100
    lo = b["concept"].map({k: lim[0] for k, lim in C.PLAUSIBLE.items()}).astype("float64")
    hi = b["concept"].map({k: lim[1] for k, lim in C.PLAUSIBLE.items()}).astype("float64")
    bad = numeric & ~((b["value"] >= lo) & (b["value"] <= hi))
    stats["implausible"] += int(bad.sum())
    b = b.loc[~bad]

    out = pd.DataFrame({
        "lopnr_swed": C.to_lopnr(b["lopnr_swed"]).values,
        "t": C.as_utc(b["datetime_analysis"]).dt.tz_convert(None).values,
        "concept": b["concept"].values,
        "value": b["value"].astype("float64").values,
        "text": b["text"].astype("object").values,
    })
    return out.loc[C.not_excluded(out)]


def match_to_visits(r, w):
    """Attach each reading to the patient's latest visit whose window has opened,
    keep it if it is before that window closes, then keep the first reading per visit and concept."""
    r = r.sort_values("t", kind="mergesort")
    ws = w.loc[w["lopnr_swed"].isin(r["lopnr_swed"].unique())]
    m = pd.merge_asof(r, ws, left_on="t", right_on="win_start", by="lopnr_swed", direction="backward")
    m = m.loc[m["visit_id"].notna() & (m["t"] <= m["win_end"])]
    if m.empty:
        return None
    m = m.drop_duplicates(["visit_id", "concept"], keep="first")  # already sorted by time
    return pd.DataFrame({
        "visit_id": m["visit_id"].astype("int64").values,
        "concept": m["concept"].values,
        "value": m["value"].values,
        "text": m["text"].values,
        "minutes": ((m["t"] - m["arrival"]) / pd.Timedelta(minutes=1)).values,
    })


def collect_vitals(v):
    w = visit_windows(v)
    found, unmatched = [], {}
    for table in C.VITAL_SOURCES:
        path = C.source_path(table)
        if not path.exists():
            C.log(f"{table}: file not found, skipped ({path})")
            continue
        names = C.file_columns(path)
        missing = [c for c in VITAL_COLUMNS if c not in names]
        if missing:
            C.log(f"{table}: no column(s) {missing}, skipped")
            continue
        columns = VITAL_COLUMNS + [c for c in VITAL_OPTIONAL if c in names]
        stats = new_vital_stats()
        n_batches = 0
        for b in C.iter_batches(path, columns):
            stats["read"] += len(b)
            r = clean_vital_batch(b, stats, unmatched)
            m = match_to_visits(r, w) if len(r) else None
            if m is not None:
                stats["matched"] += len(m)
                found.append(m)
            n_batches += 1
            if len(found) >= COMPACT_EVERY:
                found = [C.keep_first(found, ["visit_id", "concept"], "minutes")]
            if n_batches % 50 == 0:
                C.log(f"  {table}: {stats['read']:,} rows read")
        C.log(f"{table}: read {stats['read']:,} | vital rows {stats['vital_rows']:,} | "
              f"inexact time {stats['inexact']:,} | unsplittable Blodtryck {stats['bp_unsplit']:,} | "
              f"no value {stats['no_value']:,} | implausible {stats['implausible']:,} | "
              f"first-in-window readings {stats['matched']:,}")

    if unmatched:
        C.log("vital-like term names NOT collected (add to VITAL_TERMS if wanted):")
        for term, n in sorted(unmatched.items(), key=lambda kv: -kv[1])[:40]:
            C.log(f"    {n:>12,}  {term!r}")

    wide = pd.DataFrame(index=pd.Index([], name="visit_id", dtype="int64"))
    if not found:
        C.log("no vital readings matched any visit")
    else:
        first = C.keep_first(found, ["visit_id", "concept"], "minutes")
        values = first.pivot(index="visit_id", columns="concept", values="value")
        texts = first.pivot(index="visit_id", columns="concept", values="text")
        wide = pd.DataFrame(index=values.index)
        for concept in C.CONCEPTS:
            source = values if concept in C.NUMERIC_CONCEPTS else texts
            if concept in source.columns:
                wide[concept] = source[concept]
    return wide


def add_missing_concepts(out):
    """Every concept gets its column, also when no file had it."""
    for concept in C.CONCEPTS:
        if concept not in out.columns:
            out[concept] = float("nan") if concept in C.NUMERIC_CONCEPTS else pd.Series(pd.NA, index=out.index, dtype="object")
        if concept in C.TEXT_CONCEPTS:
            out[concept] = out[concept].astype("object")
    return out


# ---------------------------------------------------------------- diagnosis ---
def collect_diagnoses(v):
    path = C.source_path(C.PATREG)
    C.log(f"reading diagnoses from {path}")
    d = pd.DataFrame({
        "visit_id": v["visit_id"].values,
        "lopnr_swed": v["lopnr_swed"].values,
        "arrival_date": C.to_local_date(v["ed_arrival_datetime"]).values,
    }).sort_values("arrival_date", kind="mergesort").reset_index(drop=True)
    window = pd.Timedelta(days=C.DIAG_WINDOW_DAYS)
    first_day, last_day = d["arrival_date"].min(), d["arrival_date"].max() + window
    patients = pd.Index(d["lopnr_swed"].unique())

    found = []
    coverage_end = None
    n_read = n_used = n_batches = 0
    for b in C.iter_batches(path, PATREG_COLUMNS):
        n_read += len(b)
        dated = b["INDATUM"].notna()
        if dated.any():
            batch_max = b.loc[dated, "INDATUM"].max()
            coverage_end = batch_max if coverage_end is None else max(coverage_end, batch_max)
        b = b.loc[dated & b["Hdia"].notna()].copy()
        b["lopnr_swed"] = C.to_lopnr(b["lopnr_swed"])
        b = b.loc[(b["INDATUM"] >= first_day) & (b["INDATUM"] <= last_day)
                  & b["lopnr_swed"].isin(patients) & C.not_excluded(b)]
        n_batches += 1
        if b.empty:
            continue
        n_used += len(b)
        b = b.sort_values("INDATUM", kind="mergesort")
        left = d.loc[d["lopnr_swed"].isin(b["lopnr_swed"].unique())]
        m = pd.merge_asof(left, b, left_on="arrival_date", right_on="INDATUM", by="lopnr_swed",
                          direction="forward", tolerance=window)
        m = m.loc[m["INDATUM"].notna(), ["visit_id", "arrival_date", "INDATUM", "Hdia"]]
        if len(m):
            found.append(m)
        if len(found) >= COMPACT_EVERY:
            found = [C.keep_first(found, "visit_id", "INDATUM")]
        if n_batches % 50 == 0:
            C.log(f"  patreg: {n_read:,} rows read")

    if coverage_end is None:
        raise SystemExit(f"{path.name} has no INDATUM values")
    C.log(f"patreg: read {n_read:,} | Hdia rows in the visits' date range {n_used:,} | "
          f"last INDATUM {coverage_end:%Y-%m-%d}")

    if found:
        first = C.keep_first(found, "visit_id", "INDATUM")
    else:
        first = pd.DataFrame({"visit_id": pd.Series([], dtype="int64"),
                              "INDATUM": pd.Series([], dtype="datetime64[ns]"),
                              "Hdia": pd.Series([], dtype="object")})
    diag = d[["visit_id", "arrival_date"]].merge(
        first[["visit_id", "INDATUM", "Hdia"]], on="visit_id", how="left")
    covered = diag["arrival_date"] + window <= coverage_end
    diag["diagnosis"] = diag["Hdia"].astype("object")
    diag.loc[diag["diagnosis"].isna() & covered, "diagnosis"] = "NODIAG"
    diag["diagnosis_days"] = (diag["INDATUM"] - diag["arrival_date"]).dt.days.astype("float64")
    n_found = int(diag["Hdia"].notna().sum())
    n_nodiag = int((diag["diagnosis"] == "NODIAG").sum())
    C.log(f"diagnosis: Hdia found {n_found:,} | NODIAG {n_nodiag:,} | "
          f"not covered by patreg (null) {len(diag) - n_found - n_nodiag:,} | "
          f"found exactly on day {C.DIAG_WINDOW_DAYS}: {int((diag['diagnosis_days'] == C.DIAG_WINDOW_DAYS).sum()):,}")
    return diag[["visit_id", "diagnosis"]]


# --------------------------------------------------------------------- main ---
def main():
    C.check_settings()
    v = load_visits()
    vitals = collect_vitals(v)
    diag = collect_diagnoses(v)

    out = v[["visit_id", "lopnr_swed", "ed_hospital", "ed_arrival_datetime", "complaint"]]
    del v
    out = out.merge(vitals, left_on="visit_id", right_index=True, how="left")
    out = add_missing_concepts(out)
    out = out.merge(diag, on="visit_id", how="left")
    out = out.sort_values("visit_id").reset_index(drop=True)  # visit_id is internal only
    out = out[["lopnr_swed", "ed_hospital", "ed_arrival_datetime", "complaint"]
              + C.CONCEPTS + ["diagnosis"]]

    C.log("share of visits with each vital: " + ", ".join(
        f"{concept} {out[concept].notna().mean():.3f}" for concept in C.CONCEPTS))
    C.log("visits per hospital with any vital: " + ", ".join(
        f"{h} {g[C.CONCEPTS].notna().any(axis=1).mean():.2f}"
        for h, g in out.groupby("ed_hospital", observed=True)))
    C.write_parquet(out, "visits.parquet")


if __name__ == "__main__":
    main()
